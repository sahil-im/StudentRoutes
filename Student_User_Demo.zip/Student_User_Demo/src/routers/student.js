const express =require('express');

const router =new express.Router();
const Studentmodel = require("../Models/students.js");


router.get('/Student', async (req, res) => {
    try {
        const user = await Studentmodel.find();
        res.status(200).send(user);
    }
    catch (err) {
        res.status(400).send(err)
    }
})
router.get('/Student/:id',async(req,res) =>
{
    try{
        const _id = req.params.id;
        const userData = await Studentmodel.findById(_id);
        res.status(200).send(userData);
        if(!userData)
        {
            res.status(404).send()
        }else
        {
        console.log(userData);
        }
    }
    catch(err)
    {
        res.status(400).send(err);
    }

})

router.post('/Student', async (req, res) => {
    try {
        const user = new Studentmodel(req.body);
        const data = await user.save();
        res.status(200).send(data);
    }
    catch (err) {
        res.status(400).send(err);
    }
});

router.patch('/Student/:id', async (req, res) => {
    try 
    {
        const _id =req.params.id
        const UpdateStud = await Studentmodel.findByIdAndUpdate(_id,req.body,
            {
                new:true
            });
        res.status(200).send("Upadate sucessful")
        console.log(UpdateStud);
    }
    catch(err)
    {
        res.status(400).send("upadate unsucessful")
    }
});

router.delete('/Student/:id',async (req,res) =>
{
    try{
        const _id =req.params.id;
        const  Delete_stud = await Studentmodel.findByIdAndDelete(_id);
        if(!Delete_stud)
        {
            res.status(404).send(e)
        }else
        {
            res.status(200).send("Delete Sucessful")
        }
    }
    catch(error)
    {
            res.status(404).send(error);
    }
})

module.exports = router 