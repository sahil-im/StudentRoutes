const mongoose = require('mongoose');
const validator = require('validator');

const studentSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        minlength: 3,
        maxlength: 30,
        trim: true
    },
    Email:
    {
        type: String,
        required: true,
        unique: [true, "These Email already Used "],
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new error("Invalid Email");
            }
        }
    },
    Phone:
    {
        type: Number,
        required: true,
        min: 10,
       // max: 10,
        unique: true
    },
    address:
    {
        type:String,
        minlength:1,
        maxlength:50,
        required:true,
    }
});

const Studentmodel = new mongoose.model('StudentInfo',studentSchema);
module.exports = Studentmodel;