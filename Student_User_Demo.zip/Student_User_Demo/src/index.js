const express = require('express');
const app = express();
require("./db/conn.js");
const Studentmodel = require("./Models/students.js");
const StudentRouter =require("./routers/student.js")
PORT = 3000;
app.use(express.json());
app.use(StudentRouter)

app.listen(PORT, () => {
    console.log(`Listening port no ${PORT}`);

})

